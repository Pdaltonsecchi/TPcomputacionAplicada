#!bin/bash/
show_help() {
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo "Ejemplo: $0 /etc /backup_dir"
}

if [ "$1" == "-h" ]; then
    show_help
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: Se requieren dos argumentos."
    show_help
    exit 1
fi

origen=$1
destino=$2

if [ ! -d "$origen" ] || [ ! -d "$destino" ]; then
    echo "Error: El directorio de origen o destino no existe."
    exit 1
fi

if ! mountpoint -q "$destino"; then
    echo "Error: El directorio de destino no está montado."
    exit 1
fi

fecha=$(date +%Y%m%d)
nombre_backup=$(basename "$origen")
archivo_backup="${destino}/${nombre_backup}_bkp_${fecha}.tar.gz"

# backup
tar -czf "$archivo_backup" "$origen"

echo "Backup completado: $archivo_backup"
